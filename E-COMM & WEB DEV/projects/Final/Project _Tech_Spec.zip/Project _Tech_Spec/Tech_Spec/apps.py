from django.apps import AppConfig


class TechSpecConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Tech_Spec'
